Path should be given as follows:

python <file name> NLP6320_POSTaggedTrainingSet-Windows.txt  "The standard Turbo engine is hard to work"

(Example :  python UniGrams_NoS.py NLP6320_POSTaggedTrainingSet-Windows.txt  "The standard Turbo engine is hard to work")


file names( <file name>)

1. UniGrams_NoS.py

2. Bigrams_NoS.py

3. Bigrams_AoS

4. Bigrams_GTS



if only want the probabilities of the corpus - print statements need to be uncommented and arv[2] also should be commented